import{ai as o,aj as n}from"./index-CdsLBd0_.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
