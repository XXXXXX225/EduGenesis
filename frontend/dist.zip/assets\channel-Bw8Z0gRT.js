import{ai as o,aj as n}from"./index-C3N-poKh.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
